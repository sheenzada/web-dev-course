function dark(darkChek){
   
    if(darkChek.value==2)
    {
      document.body.style.backgroundColor='black', document.body.style.color='white';
     
    }
    
   else if(darkChek.value==1){
      document.body.style.backgroundColor='white' , document.body.style.color='black';

    }
  }